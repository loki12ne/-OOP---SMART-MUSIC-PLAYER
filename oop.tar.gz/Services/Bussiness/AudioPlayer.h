#ifndef _AUDIOPLAYER_SERVICE_H_
#define _AUDIOPLAYER_SERVICE_H_

#include <memory>
#include <string>
#include "../../Models/AudioPlayer.h"

class AudioPlayerService {
    std::shared_ptr<AudioPlayerAbstraction> audioPlayer;

public:
    explicit AudioPlayerService(std::shared_ptr<AudioPlayerAbstraction> player);

    void playAudio(const std::string& audio);
};

#endif
